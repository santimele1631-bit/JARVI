package com.jarvis.app

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

private const val DEFAULT_MODEL = "gemini-flash-latest"

class MainActivity : ComponentActivity() {
    private lateinit var tts: TextToSpeech

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts.language = Locale.getDefault() }
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF3DDCFF),
                    background = Color(0xFF060B14),
                    surface = Color(0xFF0E1A2B)
                )
            ) { Jarvis(prefs) }
        }
    }

    override fun onDestroy() {
        tts.shutdown()
        super.onDestroy()
    }

    private fun speak(t: String) {
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    @Composable
    private fun Jarvis(prefs: SharedPreferences) {
        var key by remember { mutableStateOf(prefs.getString("key", "").orEmpty()) }
        var model by remember { mutableStateOf(prefs.getString("model", null) ?: DEFAULT_MODEL) }
        var settings by remember { mutableStateOf(key.isBlank()) }
        var input by remember { mutableStateOf("") }
        var busy by remember { mutableStateOf(false) }
        val msgs = remember { mutableStateListOf<Msg>() }
        val list = rememberLazyListState()
        val scope = rememberCoroutineScope()

        fun send(text: String) {
            if (text.isBlank() || busy) return
            msgs.add(Msg("user", text))
            input = ""
            val local = Local.handle(this@MainActivity, text)
            if (local != null) {
                msgs.add(Msg("model", local)); speak(local); return
            }
            if (key.isBlank()) {
                msgs.add(Msg("model", "Falta la API key de Gemini. Pégala en ⚙.")); return
            }
            val k = key
            val m = model
            val history = msgs.toList()
            busy = true
            scope.launch {
                val reply = withContext(Dispatchers.IO) {
                    try {
                        Gemini.ask(k, m, history)
                    } catch (e: Exception) {
                        "Error: " + (e.message ?: "sin conexión")
                    }
                }
                msgs.add(Msg("model", reply))
                busy = false
                speak(reply)
            }
        }

        val mic = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == Activity.RESULT_OK) {
                r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
                    ?.let { send(it) }
            }
        }

        LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.animateScrollToItem(msgs.lastIndex) }

        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(12.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "J.A.R.V.I.S.",
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = { settings = true }) { Text("⚙") }
                }
                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth(),
                    state = list,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(msgs) { m ->
                        val me = m.role == "user"
                        Box(
                            Modifier.fillMaxWidth(),
                            contentAlignment = if (me) Alignment.CenterEnd else Alignment.CenterStart
                        ) {
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = if (me) Color(0xFF12324A) else MaterialTheme.colorScheme.surface
                            ) { Text(m.text, Modifier.padding(10.dp).widthIn(max = 300.dp)) }
                        }
                    }
                    if (busy) item { Text("…", color = MaterialTheme.colorScheme.primary) }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        input, { input = it }, Modifier.weight(1f),
                        placeholder = { Text("Escribe o habla…") }, maxLines = 3
                    )
                    TextButton(onClick = {
                        try {
                            mic.launch(
                                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                            )
                        } catch (e: Exception) {
                            msgs.add(Msg("model", "Este móvil no tiene reconocimiento de voz."))
                        }
                    }) { Text("🎤") }
                    Button(onClick = { send(input) }, enabled = !busy) { Text("➤") }
                }
            }
        }

        if (settings) {
            var k by remember { mutableStateOf(key) }
            var m by remember { mutableStateOf(model) }
            AlertDialog(
                onDismissRequest = { if (key.isNotBlank()) settings = false },
                title = { Text("Ajustes") },
                text = {
                    Column {
                        OutlinedTextField(
                            k, { k = it }, label = { Text("API key de Gemini") },
                            singleLine = true, visualTransformation = PasswordVisualTransformation()
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(m, { m = it }, label = { Text("Modelo") }, singleLine = true)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        key = k.trim()
                        model = m.trim().ifBlank { DEFAULT_MODEL }
                        prefs.edit().putString("key", key).putString("model", model).apply()
                        settings = false
                    }) { Text("Guardar") }
                }
            )
        }
    }
}
