package com.jarvis.app

import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.DateFormat
import java.util.Date
import java.util.Locale

data class Msg(val role: String, val text: String) // role: "user" | "model"

object Gemini {
    private const val SYSTEM = "Eres JARVIS, un asistente personal. Responde en el idioma del usuario, " +
        "de forma breve y clara (tus respuestas se leen en voz alta). Si no sabes algo, dilo sin inventar."

    /** Llamada bloqueante: ejecútala fuera del hilo principal. */
    fun ask(key: String, model: String, history: List<Msg>): String {
        val contents = JSONArray()
        for (m in history.takeLast(20)) {
            contents.put(
                JSONObject().put("role", m.role)
                    .put("parts", JSONArray().put(JSONObject().put("text", m.text)))
            )
        }
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", contents)
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val txt = stream?.bufferedReader()?.readText().orEmpty()
            if (code !in 200..299) {
                val msg = runCatching { JSONObject(txt).getJSONObject("error").getString("message") }
                    .getOrDefault(txt.take(200))
                return "Error $code: $msg"
            }
            val parts = JSONObject(txt).optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts")
                ?: return "Gemini no devolvió texto (¿respuesta bloqueada?)."
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
            return sb.toString().trim().ifEmpty { "No obtuve respuesta del modelo." }
        } finally {
            c.disconnect()
        }
    }
}

/** Comandos que se resuelven en el móvil, sin gastar API. Devuelve null si no es uno. */
object Local {
    fun handle(ctx: Context, input: String): String? {
        val t = input.lowercase().trim().trimEnd('.', '!', '?')
        val loc = Locale.getDefault()
        val simple = t.length < 30 && " en " !in t
        return when {
            simple && ("qué hora" in t || "que hora" in t) ->
                "Son las " + DateFormat.getTimeInstance(DateFormat.SHORT, loc).format(Date()) + "."
            simple && ("qué día" in t || "que dia" in t || "qué fecha" in t || "que fecha" in t) ->
                "Hoy es " + DateFormat.getDateInstance(DateFormat.FULL, loc).format(Date()) + "."
            t.startsWith("abre ") || t.startsWith("abrir ") -> open(ctx, t.substringAfter(' ').trim())
            else -> null
        }
    }

    private fun open(ctx: Context, name: String): String {
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val app = pm.queryIntentActivities(launcher, 0)
            .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) }
            ?: return "No encuentro ninguna app llamada \"$name\"."
        val i = pm.getLaunchIntentForPackage(app.activityInfo.packageName)
            ?: return "No puedo abrir esa app."
        ctx.startActivity(i)
        return "Abriendo " + app.loadLabel(pm) + "."
    }
}
